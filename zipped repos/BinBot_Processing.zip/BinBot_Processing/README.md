# BinBot_Processing
Repository containing the server data processing for BinBot
