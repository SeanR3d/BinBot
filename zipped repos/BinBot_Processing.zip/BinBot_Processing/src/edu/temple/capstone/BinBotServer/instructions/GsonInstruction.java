package edu.temple.capstone.BinBotServer.instructions;

import java.util.List;
import java.util.Map;

public class GsonInstruction
{
	public String status;
	public String img;
	public List<Map<String, Double>> treads;
	public List<Double> arms;
}
