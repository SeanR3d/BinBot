package edu.temple.capstone.BinBotServer.instructions;

public enum Status {
    PATROL,
    MOVE,
    RETRIEVE,
    RETRIEVED
}
