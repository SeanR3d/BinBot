package edu.temple.capstone.BinBotServer.instructions;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.*;


class TreadInstructionTest
{
	@Test
	void calcInstructionsTest() {
//		List<Movement> list = TreadInstruction.calcInstructions(0, 0, 0, 0, 0, 0, 32);
//		assertEquals(0.0, list.get(0).angle());
//		assertEquals(0.0, list.get(0).distance());
	}
}
