# BinBot_OperatorMobileApp
Repository containing the operator Android mobile application for BinBot
