package BinBotDemo1.instructions;

public enum Status {
    PATROL,
    NAVIGATE,
    RETRIEVE
}
