# BinBot_Demo1_Client
Small client to interact with server so that machine learning and server capabilities can be demonstrated
